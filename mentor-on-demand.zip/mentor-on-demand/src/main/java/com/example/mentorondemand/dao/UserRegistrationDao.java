package com.example.mentorondemand.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.mentorondemand.model.UserRegistration;


@Repository
public interface UserRegistrationDao extends JpaRepository<UserRegistration,Integer> {
	List<UserRegistration> findByEmail(String email);
}
