package com.example.mentorondemand.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.mentorondemand.model.MentorRegistration;


@Repository
public interface MentorDao extends JpaRepository<MentorRegistration,Integer> {

	List<MentorRegistration> findByEmail(String email);
	@Query("select m from MentorRegistration m where m.technologiesKnown like %:technology%")
	List<MentorRegistration> getMentorListWithPattern(@Param("technology")String technology);
}
