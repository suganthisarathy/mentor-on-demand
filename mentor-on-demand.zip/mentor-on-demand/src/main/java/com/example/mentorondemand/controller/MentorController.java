package com.example.mentorondemand.controller;

import org.springframework.web.servlet.ModelAndView;

public interface MentorController {

	ModelAndView getCourseList() throws Exception;

	ModelAndView getRequestList() throws Exception;

	

}
